import {
  Engine,
  regeneratorRuntime,
  DateExtension,
  Rest
} from './engine/index'

DateExtension.init()

App({
  globalData: {
    userInfo: null
  },
  onLaunch: async function () {
    await Engine.init(Rest)
  }
})
