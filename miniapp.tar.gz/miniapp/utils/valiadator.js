import { wx } from '../engine/index.js'

export const isPhone = (phone) => {
  let reg = /^1\d{10}$/
  return reg.test(phone)
}

const getNicknameLength = (str) => {
  let len = 0

  for (let i = 0; i < str.length; i++) {
    let c = str.charAt(i)

    if (c.match(/[\u4E00-\u9FA5]/) != null) {
      len += 2
    } else {
      len += 1
    }
  }

  return len
}

export const substrNickname = (str) => {
  let chineseCharacter = 0
  let anotherCharacter = 0

  for (let i = 0; i < str.length; i++) {
    let c = str.charAt(i)

    if (c.match(/[\u4E00-\u9FA5]/) != null) {
      chineseCharacter++
    } else {
      anotherCharacter++
    }

    if (chineseCharacter * 2 + anotherCharacter > 19) {
      return str.substr(0, chineseCharacter + anotherCharacter)
    }
  }

  return str
}

export const checkName = (name) => {
  const length = getNicknameLength(name)

  return length >= 2 && length <= 20
}

export const validateFields = (fields) => {
  if (!fields || Object.getOwnPropertyNames(fields).length < 1) {
    return true
  }

  for (let key in fields) {
    const field = fields[key]
    const value = field.value
    const message = field.message
    const isError = (!value) || (typeof (value) === 'string' && !value.trim()) || (value instanceof Array && value.length < 1)

    if (isError) {
      wx.showToast({ title: message, icon: 'none' })
      return false
    }

    if (field.validators && field.validators.length > 0) {
      for (let validateFunction of field.validators) {
        if (!validateFunction(value)) {
          wx.showToast({ title: message, icon: 'none' })
          return false
        }
      }
    }
  }

  return true
}
