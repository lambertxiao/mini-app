import { SequencePage, wx, regeneratorRuntime, Storage, Engine, Enums, Util } from '../../engine/index'
import MemberService from '../../services/memberService'

const beforeAuth = async (vm) => {
  const oauthResult = await Storage.getItem('oauthResult')
  // 如果关注了同个主体的公众号，可以获取到unionId
  const { unionId, channelId, openId } = oauthResult

  if (unionId) {
    const { status, member } = await MemberService.isActivatedMember(channelId, unionId, openId)

    if (status === 'isActivated') {
      wx.redirectTo({
        url: '../../pages/member/center?parksonMemberId=' + member.id
      })

      return
    }
  }

  redirectToGuidePage(vm, unionId)
}

const redirectToGuidePage = async (vm, unionId = '') => {
  const res = await wx.getSetting()

  if (res.authSetting['scope.userInfo']) {
    if (unionId) {
      const { userInfo } = await wx.getUserInfo({ withCredentials: true })
      Storage.setItem('userInfo', userInfo)
    } else {
      await Engine.login(Enums.Scopes.USER_INFO)
    }

    wx.redirectTo({ url: '../../pages/guide/index' })
    return
  }

  vm.setData({ loading: false })
}

SequencePage({
  data: {
    loading: true,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  async onLoad (option) {
    Util.setDocumentTitle('crm')
    await beforeAuth(this)
    await Storage.setItem('storeCode', option.storeCode || '')
  },
  async bindGetUserInfo (e) {
    if (e.detail.errMsg === 'getUserInfo:ok') {
      await Engine.login(Enums.Scopes.USER_INFO, true)
      wx.redirectTo({ url: '../../pages/guide/index' })
    }
  },
  cannotUse (e) {
    wx.showModal({
      title: '提示',
      content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
    })
  }
})
