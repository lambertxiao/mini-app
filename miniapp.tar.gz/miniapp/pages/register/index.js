import { Engine, SequencePage, Storage, regeneratorRuntime, Rest, wx, Util } from '../../engine/index'
import Captcha from '../../services/captcha'
import memberService from '../../services/memberService'
import { checkName, isPhone, substrNickname } from '../../utils/valiadator'

const validateInput = (vm) => {
  let hasError = ''
  if (!vm.data.phone) {
    hasError = '请输入手机号码'
  } else if (!isPhone(vm.data.phone)) {
    hasError = '手机号码格式不正确'
  } else if (!vm.data.picCaptcha) {
    hasError = '请输入图片验证码'
  }
  if (hasError) {
    wx.showToast({
      title: hasError,
      icon: 'none'
    })
    return true
  }
  return false
}

const fetchStores = async (vm) => {
  const resp = await Rest.get('/crm/member/get-mini-stores', {}, true)
  if (vm.data.hasStoreCode) {
    resp.data.forEach((store, index) => {
      if (store.storeCode === vm.data.storeCode) {
        vm.setData({
          storeIndex: index,
          accountId: resp.data[index].accountId
        })
      }
    })
  } else {
    vm.setData({
      storeCode: resp.data[vm.data.storeIndex].storeCode,
      accountId: resp.data[vm.data.storeIndex].accountId
    })
  }
  vm.setData({
    storeItem: resp.data
  })
}

const checkInfo = (vm) => {
  let hasError = ''
  if (!checkName(vm.data.name)) {
    hasError = '姓名长度限制2-20个字符，请重新输入'
  }

  if (hasError) {
    wx.showToast({
      title: hasError,
      icon: 'none'
    })
    return false
  }
  if (vm.data.needValidatePhone) {
    if (!validatePhoneCaptcha(vm)) {
      return false
    }
  }
  return true
}

const validatePhoneCaptcha = (vm) => {
  let hasError = validateInput(vm)
  if (!hasError) {
    if (!vm.data.isCaptchaSent) {
      hasError = '请先发送手机验证码'
    } else if (!vm.data.phoneCaptcha) {
      hasError = '请输入手机验证码'
    }
    if (hasError) {
      wx.showToast({
        title: hasError,
        icon: 'none'
      })
      return false
    }
    return true
  }
  return false
}

const fetchProperties = async (vm) => {
  const resp = await Rest.get('/crm/member-property/get-mini-register-properties', {}, true)
  vm.setData({
    extProperties: resp.data
  })
}

const getProperties = (vm, properties) => {
  const props = []
  let propertity = {}
  properties.forEach((item) => {
    if (item.name === 'name') {
      propertity = {
        id: item.id,
        name: item.name,
        value: vm.data.name
      }
    } else if (item.name === 'gender') {
      propertity = {
        id: item.id,
        name: item.name,
        value: getGenderValue(vm, vm.data.gender)
      }
    } else if (item.name === 'birthday') {
      propertity = {
        id: item.id,
        name: item.name,
        value: new Date(vm.data.birthday).getTime()
      }
    }
    props.push(propertity)
  })
  return props
}

const getGenderValue = (vm, value) => {
  if (value === '男') {
    return 'male'
  }
  return 'female'
}

SequencePage({
  data: {
    accountId: '',
    disabled: false,
    captchaUrl: '',
    picCaptcha: '',
    phoneCaptcha: '',
    name: '',
    nickname: '',
    phone: '',
    codeId: '',
    needValidatePhone: true,
    hasStoreCode: false,
    storeCode: '',
    storeItem: [],
    isCaptchaSent: false,
    storeIndex: 0,
    genderItem: ['男', '女'],
    gender: '男',
    genderIndex: 0,
    birthday: '',
    birthdayTitle: '生日',
    sendCountDownText: '获取',
    isDisableSendCaptcha: false,
    extProperties: [],
    loading: true
  },
  async onShow(options) {
    Util.setDocumentTitle('申请会员卡')
    const { channelId, openId, unionId } = await Storage.getItem('oauthResult')
    const resp = await memberService.isActivatedMember(channelId, unionId, openId)

    if (resp.status !== 'isActivated') {
      let userInfo = await Storage.getItem('userInfo')
      if (userInfo) {
        if (userInfo.nickName) {
          this.setData({
            name: substrNickname(userInfo.nickName),
            nickname: userInfo.nickName
          })
        }
        if (userInfo.gender) {
          this.setData({
            genderIndex: userInfo.gender - 1,
            gender: this.data.genderItem[userInfo.gender - 1]
          })
        }
      }

      let phone = await Storage.getItem('phone')
      let storeCode = await Storage.getItem('storeCode')
      if (phone) {
        this.setData({
          needValidatePhone: false,
          phone: phone
        })
      }
      if (storeCode) {
        this.setData({
          hasStoreCode: true,
          storeCode: storeCode
        })
      }
      fetchStores(this)
      fetchProperties(this)
      Captcha.getPicCaptcha(this)
    } else {
      wx.redirectTo({ url: '../member/center?parksonMemberId=' + resp.member.id })
    }
    this.setData({ loading: false })
  },
  async fetchAnotherPicCaptcha() {
    Captcha.getPicCaptcha(this)
  },
  nameInputEvent(e) {
    this.setData({ name: e.detail.value })
  },
  phoneInputEvent(e) {
    this.setData({ phone: e.detail.value })
  },
  picCaptchaInputEvent(e) {
    this.setData({ picCaptcha: e.detail.value })
  },
  phoneCaptchaInputEvent(e) {
    this.setData({ phoneCaptcha: e.detail.value })
  },
  async fetchPhoneCaptcha() {
    if (!this.data.isDisableSendCaptcha && !validateInput(this)) {
      await Captcha.getPhoneCaptcha(this)
    }
  },
  bindStoreChange(e) {
    this.setData({
      storeIndex: e.detail.value,
      storeCode: this.data.storeItem[e.detail.value].storeCode,
      accountId: this.data.storeItem[e.detail.value].accountId
    })
  },
  bindGenderChange(e) {
    this.setData({
      genderIndex: e.detail.value,
      gender: this.data.genderItem[e.detail.value]
    })
  },
  bindBirthdayChange(e) {
    this.setData({ birthday: e.detail.value })
  },
  changePhone() {
    this.setData({
      needValidatePhone: true,
      phone: ''
    })
  },
  async submit() {
    this.setData({ disabled: true })
    if (!checkInfo(this)) {
      this.setData({ disabled: false })
      return
    }
    const properties = getProperties(this, this.data.extProperties)
    const params = {
      accountId: this.data.accountId,
      openId: Engine.oauthResult.openId,
      channelId: Engine.oauthResult.channelId,
      unionId: Engine.oauthResult.unionId,
      store: {
        storeName: this.data.storeItem[this.data.storeIndex].name,
        storeCode: this.data.storeCode
      },
      fromMiniApp: true,
      name: this.data.name,
      phone: this.data.phone,
      properties: properties,
      nickname: this.data.nickname
    }

    if (this.data.needValidatePhone) {
      params.captcha = this.data.phoneCaptcha
    }

    const resp = await Rest.post('/crm/member/create', params)
    switch (resp.data.status) {
      case 'hasBound':
        wx.showToast({
          title: '该手机号已绑定过会员, 请联系管理员',
          icon: 'none'
        })
        break
      case 'isActivated':
        wx.showToast({
          title: '您已是会员, 请到会员中心查看',
          icon: 'none',
          complete: () => {
            setTimeout(() => {
              wx.navigateTo({
                url: '../member/center?parksonMemberId=' + resp.data.memberId
              })
            }, 2000)
          }
        })
        break
      case 'isNewMember':
        wx.navigateTo({
          url: '../success/index?parksonMemberId=' + resp.data.memberId
        })
        break
      case 'isParksonOfflineMember':
        Storage.setItem(Engine.oauthResult.unionId + 'memberInfo', {
          'phone': this.data.phone,
          'storeCode': this.data.storeCode
        })
        wx.navigateTo({
          url: '../activate/index'
        })
        break
    }
    this.setData({ disabled: false })
  }
})
