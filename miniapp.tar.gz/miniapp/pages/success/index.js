import { Engine, SequencePage, regeneratorRuntime, Rest, wx, Util } from '../../engine/index'
import MemberService from '../../services/memberService'

SequencePage({
  data: {
    member: '',
    loading: true
  },
  async onLoad(options) {
    Util.setDocumentTitle('申请会员卡')
    const resp = await MemberService.getMemberInfo(options.parksonMemberId)
    let member = resp.member
    member.cardNumber = member.cardNumber.replace(/\B(?=(\d{4})+(?!\d))/g, ' ')
    this.setData({
      member: member,
      loading: false
    })
  },
  toMember(){
    wx.navigateTo({
      url: '../../pages/member/center?parksonMemberId=' + this.data.member.id
    })
  }
})
