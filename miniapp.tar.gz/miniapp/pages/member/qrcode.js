import { SequencePage, Util } from '../../engine/index'
import drawQrcode from '../../engine/lib/weapp.qrcode.min'

SequencePage({
  data: {
    cardNumber: ''
  },
  onLoad (option) {
    Util.setDocumentTitle('crm')
    this.setData({ cardNumber: option.cardNumber })
    drawQrcode({
      width: 200,
      height: 200,
      canvasId: 'cardNumber',
      text: option.originalCardNumber
    })
  }
})
