import { SequencePage, wx, regeneratorRuntime, Util, Storage } from '../../engine/index'
import MemberService from '../../services/memberService'

const getMemberInfo = async (parksonMemberId, vm) => {
  const resp = await MemberService.getMemberInfo(parksonMemberId)

  if (resp.status === 'ok' || resp.status === 'failed') {
    let member = resp.member
    vm.setData({ originalCardNumber: member.cardNumber })
    member.cardNumber = member.cardNumber.replace(/\B(?=(\d{4})+(?!\d))/g, ' ')
    vm.setData({ member: member })

    if (resp.status === 'failed') {
      wx.showToast({
        title: '获取会员积分失败',
        icon: 'none'
      })
    }
  } else {
    wx.redirectTo({
      url: '../../pages/guide/index'
    })
  }
}

const getChannelName = async (vm) => {
  const { channelId } = await Storage.getItem('oauthResult')
  const channelName = await MemberService.getChannelName(channelId)
  vm.setData( { channelName: channelName } )
}

SequencePage({
  data: {
    member: {},
    loading: true,
    parksonMemberId: '',
    isShowMask: false,
    channelName: '',
    originalCardNumber: ''
  },
  onLoad (option) {
    Util.setDocumentTitle('crm')
    getChannelName(this)
    this.setData( { parksonMemberId: option.parksonMemberId } )
  },
  async onShow () {
    await getMemberInfo(this.data.parksonMemberId, this)
    this.setData({ loading: false })
  },
  viewQrcode () {
    wx.navigateTo({
      url: './qrcode?cardNumber=' + this.data.member.cardNumber + '&originalCardNumber=' + this.data.originalCardNumber
    })
  },
  displayShareMask () {
    this.setData( { isShowMask: !this.data.isShowMask } )
  }
})
