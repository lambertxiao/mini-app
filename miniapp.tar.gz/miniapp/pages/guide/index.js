import { SequencePage, wx, Storage, regeneratorRuntime, Util } from '../../engine/index'
import MemberService from '../../services/memberService'

const navigateTo = async (page, e, vm) => {
  let phone = ''

  if (e.detail.errMsg === 'getPhoneNumber:ok') {
    const { encryptedData, iv } = e.detail
    const { channelId } = await Storage.getItem('oauthResult')

    phone = await MemberService.getDecryptPhone(channelId, vm.data.code, encryptedData, iv)
    await Storage.setItem('phone', phone)
  } else {
    await Storage.setItem('phone', null)
  }

  wx.navigateTo({
    url: '../../pages/' + page + '/index'
  })
}

const isActivatedMember = async (vm) => {
  const { channelId, openId, unionId } = await Storage.getItem('oauthResult')
  const { status, member } = await MemberService.isActivatedMember(channelId, unionId, openId)

  if (status === 'isActivated') {
    wx.redirectTo({
      url: '../../pages/member/center?parksonMemberId=' + member.id
    })
  }
  vm.setData({ loading: false })
}

SequencePage({
  data: {
    code: '',
    loading: true
  },
  async onShow () {
    this.setData({ loading: true })
    Util.setDocumentTitle('crm')
    const { unionId } = await Storage.getItem('oauthResult')

    if (!unionId) {
      wx.showToast({ title: '会员数据有误，请联系管理员', icon: 'none' })
      wx.redirectTo({ url: '../../pages/auth/index' })
    } else {
      const { code } = await wx.login()
      this.setData({ code: code })
      isActivatedMember(this)
    }
  },
  applyMemberCard (e) {
    navigateTo('register', e, this)
  },
  activateMemberCard (e) {
    navigateTo('checkPhone', e, this)
  }
})
