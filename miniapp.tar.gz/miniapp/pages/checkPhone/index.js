import captcha from '../../services/captcha'
import memberService from '../../services/memberService'
import { isPhone, validateFields } from '../../utils/valiadator'
import { SequencePage, wx, Rest, Engine, Storage, regeneratorRuntime, Util } from '../../engine/index'

const getStores = async (vm) => {
  const resp = await Rest.get('/crm/member/get-mini-stores', {}, true)
  if (resp.data) {
    vm.setData({ storeItems: resp.data })
  }
}

const validatePhoneAndCaptcha = (vm) => {
  return validateFields({
    phoneEmpty: {
      value: vm.data.phone,
      message: '请输入手机号码',
    },
    phone: {
      value: vm.data.phone,
      message: '手机号码格式不正确',
      validators: [isPhone]
    },
    picCaptcha: {
      value: vm.data.picCaptcha,
      message: '请输入图片验证码'
    }
  })
}

const goToActivatePage = (vm) => {
  let storeCode = vm.data.storeItems[vm.data.selectIndex] && vm.data.storeItems[vm.data.selectIndex].storeCode
  Storage.setItem(Engine.oauthResult.unionId + 'memberInfo', {
    phone: vm.data.phone,
    storeCode: storeCode
  })
  wx.navigateTo({
    url: '/pages/activate/index?fromPage=checkPhone'
  })
}

SequencePage({
  data: {
    phone: '',
    needValidatePhone: true,
    hasStoreCodeInfo: false,
    codeId: '',
    captchaUrl: '',
    picCaptcha: '',
    phoneCaptcha: '',
    sendCountDownText: '获取',
    isDisableSendCaptcha: false,
    isCaptchaSent: false,
    storeItems: [],
    selectIndex: 0,
    disabled: false,
    loading: true
  },
  async onShow() {
    Util.setDocumentTitle('绑定会员卡')
    const phone = await Storage.getItem('phone')
    const storeCode = await Storage.getItem('storeCode')
    if (phone) {
      this.setData({ needValidatePhone: false })
      this.setData({ phone: phone })
    }
    const { channelId, openId, unionId } = await Storage.getItem('oauthResult')
    const resp = await memberService.isActivatedMember(channelId, unionId, openId)
    if (resp.status !== 'isActivated') {
      await getStores(this)
      if (storeCode) {
        for (let index in this.data.storeItems) {
          if (this.data.storeItems[index].storeCode === storeCode) {
            this.setData({ selectIndex: index })
            this.setData({ hasStoreCodeInfo: true })
            break
          }
        }
      }

      if (!phone) {
        await captcha.getPicCaptcha(this)
      }
    } else {
      wx.redirectTo({ url: '../member/center?parksonMemberId=' + resp.member.id })
    }
    this.setData({ loading: false })
  },
  bindPhoneInput(e) {
    this.setData({ phone: e.detail.value })
  },
  bindPicCaptchaInput(e) {
    this.setData({ picCaptcha: e.detail.value })
  },
  bindPhoneCaptchaInput(e) {
    this.setData({ phoneCaptcha: e.detail.value })
  },
  selectstore(e) {
    this.setData({ selectIndex: e.detail.value })
  },
  getPicCaptcha(e) {
    captcha.getPicCaptcha(this)
  },
  getPhoneCaptcha(e) {
    if (!validatePhoneAndCaptcha(this)) {
      return
    }

    if (this.data.isDisableSendCaptcha) {
      return
    }

    captcha.getPhoneCaptcha(this)
  },
  async changePhone(e) {
    this.setData({ needValidatePhone: true })
    this.setData({ phone: '' })
    await captcha.getPicCaptcha(this)
  },
  async search(e) {
    if (!this.data.storeItems[this.data.selectIndex]) {
      wx.showToast({ title: '请选择门店', icon: 'none' })
      return
    }

    if (this.data.needValidatePhone) {
      let fields = {
        phoneEmpty: {
          value: this.data.phone,
          message: '请输入手机号码',
        },
        phone: {
          value: this.data.phone,
          message: '手机号码格式不正确',
          validators: [isPhone]
        },
        picCaptcha: {
          value: this.data.picCaptcha,
          message: '请输入图片验证码'
        },
        isCaptchaSent: {
          value: this.data.isCaptchaSent,
          message: '请先发送短信验证码'
        },
        phoneCaptcha: {
          value: this.data.phoneCaptcha,
          message: '请输入短信验证码'
        }
      }

      if (!validateFields(fields)) {
        return
      }
    }

    if (this.data.disabled) {
      return
    }

    this.setData({ disabled: true })

    const params = {
      captcha: this.data.phoneCaptcha,
      phone: this.data.phone,
      channelId: Engine.oauthResult.channelId,
      openId: Engine.oauthResult.openId,
      unionId: Engine.oauthResult.unionId
    }
    let resp = await Rest.get('/crm/member/check-phone-captcha', params)
    switch (resp.data.status) {
      case 'ok':
        goToActivatePage(this)
        break
      case 'hasBound':
        wx.showToast({ title: '该手机号已绑定过会员, 请联系管理员', icon: 'none' })
        break
      case 'isActivated':
        wx.showToast({
          title: '您已是会员, 请到会员中心查看',
          icon: 'none',
          complete: () => {
            setTimeout(() => {
              wx.navigateTo({
                url: '../member/center?parksonMemberId=' + resp.data.memberId
              })
            }, 2000)
          }
        })
        break
    }
    this.setData({ disabled: false })
  }
})