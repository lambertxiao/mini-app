import { SequencePage, wx, Rest, Engine, Storage, regeneratorRuntime, Util } from '../../engine/index'

const fetchCardList = async (vm) => {
  if (vm.data.mobilePhone) {
    const params = { mobilePhone: vm.data.mobilePhone }
    let response = await Rest.get('/crm/member/get-card-list', params, true)
    if (response.data['result'] === '0') {
      let cards = response.data['cards']
      vm.setData({ hasFindCards: true })
      if (cards && cards.length > 0) {
        for (let card of cards) {
          card.cardNumber = card.cardNumber.replace(/\B(?=(\d{4})+(?!\d))/g, ' ')
          card.selected = false
          if (card.name.indexOf('金卡') > -1) {
            card.prefix = 'Gold'
          }
          if (card.name.indexOf('白金卡') > -1) {
            card.prefix = 'Platinum'
          }
          if (card.name.indexOf('钻石卡') > -1) {
            card.prefix = 'Diamond'
          }
        }
        vm.setData({ cardList: cards })
      } else {
        vm.setData({ cardsFiltered: true })
      }
      vm.setData({ userName: response.data['userName'] })
    }
    vm.setData({ fetchCardListDone: true })
  }
  vm.setData({ loading: false })
}

const getBindingInfoFromLocal = async (vm) => {
  let activeInfo = await Storage.getItem(Engine.oauthResult.unionId + 'activeInfo')
  if (activeInfo) {
    vm.setData({ isActivated: activeInfo.isActivated })
    vm.setData({ selectedCard: activeInfo.selectedCard })
    vm.setData({ memberId: activeInfo.memberId })
  }

  let memberInfo = await Storage.getItem(Engine.oauthResult.unionId + 'memberInfo')
  if (memberInfo) {
    vm.setData({ mobilePhone: memberInfo.phone })
    vm.setData({ storeCode: memberInfo.storeCode })
  }
}

SequencePage({
  data: {
    cardList: [],
    mobilePhone: '',
    storeCode: '',
    memberId: '',
    userName: '',
    fromSearchCardPage: false,
    selectedCard: null,
    isActivated: false,
    isBound: false,
    hasFindCards: false,
    disabled: false,
    cardsFiltered: false,
    fetchCardListDone: false,
    loading: true
  },
  async onLoad(options) {
    const fromPage = options.fromPage
    this.setData({ fromSearchCardPage: fromPage === 'checkPhone' })
    if (this.data.fromSearchCardPage) {
      Util.setDocumentTitle('绑定会员卡')
    } else {
      Util.setDocumentTitle('申请会员卡')
    }
    await getBindingInfoFromLocal(this)
    fetchCardList(this)
  },
  selectCard(e) {
    let index = e.currentTarget.dataset.index
    let cardList = this.data.cardList
    for (let index in cardList) {
      cardList[index]['selected'] = false
    }
    cardList[index]['selected'] = true
    this.setData({ cardList: cardList })
    this.setData({ selectedCard: cardList[index] })
  },
  setActivatedStatus(memberId) {
    Storage.setItem(Engine.oauthResult.unionId + 'activeInfo', {
      isActivated: true,
      selectedCard: this.data.selectedCard,
      memberId: memberId
    })
    this.setData({ memberId: memberId })
    this.setData({ isActivated: true })
  },
  async confirmBinding(e) {
    if (!this.data.selectedCard) {
      wx.showToast({ title: '请先选择要绑定的会员卡', icon: 'none' })
      return
    }
    this.setData({ disabled: true })
    if (!this.data.isBound) {
      this.setData({ isBound: true })
      let storeCode = this.data.storeCode

      const params = {
        channelId: Engine.oauthResult.channelId,
        openId: Engine.oauthResult.openId,
        unionId: Engine.oauthResult.unionId,
        phone: this.data.mobilePhone,
        cardNumber: this.data.selectedCard['cardNumber'].replace(/\s+/g, ''),
        cardType: this.data.selectedCard['cardType'],
        storeCode: storeCode,
        userName: this.data.userName,
        fromMiniApp: true
      }
      try {
        const response = await Rest.post('/crm/member/activate-member', params)
        switch (response.data['status']) {
          case 'isActivated':
            Util.setDocumentTitle('绑定成功')
            wx.showToast({ title: '您已绑定会员卡, 请勿重复绑定', icon: 'none' })
            this.setActivatedStatus(response.data.memberInfo['memberId'])
            break
          case 'success':
            Util.setDocumentTitle('绑定成功')
            this.setActivatedStatus(response.data['memberId'])
            break
          case 'failed':
            wx.showToast({ title: '您绑定的会员卡不存在', icon: 'none' })
            break
        }
      } finally {
        this.setData({ isBound: false })
        this.setData({ disabled: false })
      }
    }
  },
  goToDetail(e) {
    wx.redirectTo({ url: '../member/center?parksonMemberId=' + this.data.memberId })
  },
  applyMemberCard(e) {
    wx.redirectTo({ url: '../register/index' })
  }
})
