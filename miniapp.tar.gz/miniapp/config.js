export default class config {
  static env = 'prod'

  static envs = {
    dev: {
      oauthUrl: 'https://dev-oauth.quncrm.com',
      baseUrl: 'https://dev-ajax.quncrm.com',
      webViewUrl: 'https://dev.quncrm.com',
      baseResourceUrl: 'https://dev-statics.crm.com'
    }
  }

  static getOauthUrl = () => {
    return config.envs[config.env].oauthUrl
  }

  static getBaseUrl = () => {
    return config.envs[config.env].baseUrl
  }

  static getWebViewUrl = () => {
    return config.envs[config.env].webViewUrl
  }
}
