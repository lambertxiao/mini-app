import Rest from '../engine/Rest'
import { regeneratorRuntime, wx } from '../engine/index.js'

export default class Captcha {
  static sendCaptchaFailHandler = (vm, resp) => {
    Captcha.getPicCaptcha(vm)
    vm.setData({ isDisableSendCaptcha: false })
    vm.setData({ isCaptchaSent: false })
  }

  static sendCaptchaSuccessHandler = (vm, resp) => {
    if (resp.data.message === 'Error') {
      wx.showToast({
        title: resp.data.data,
        icon: 'none'
      })
      vm.setData({ isDisableSendCaptcha: false })
      vm.setData({ isCaptchaSent: false })
    } else {
      let millis = 180
      const timer = setInterval(() => {
        if (millis > 1) {
          vm.setData({ sendCountDownText: `${--millis} 秒` })
        } else {
          clearInterval(timer)
          Captcha.getPicCaptcha(vm)
          vm.setData({ isDisableSendCaptcha: false })
          vm.setData({ sendCountDownText: '获取' })
        }
      }, 1000)
      wx.showToast({
        title: `验证码短信已发送至${vm.data.phone} `,
        icon: 'none'
      })
    }
    vm.setData({ isCaptchaSent: true })
  }

  static getPicCaptcha = async (vm) => {
    const res = await Rest.get('/crm/member/get-captcha', {})
    vm.setData({ captchaUrl: res.data.data })
    vm.setData({ codeId: res.data.codeId })
  }

  static getPhoneCaptcha = async (vm) => {
    const params = {
      phone: vm.data.phone,
      code: vm.data.picCaptcha,
      type: 'signup',
      codeId: vm.data.codeId
    }
    vm.setData({ isDisableSendCaptcha: true })

    const resp = await Rest.post('/crm/member/send-captcha', params)
    if (resp.statusCode === 200) {
      Captcha.sendCaptchaSuccessHandler(vm, resp)
    } else {
      Captcha.sendCaptchaFailHandler(vm, resp)
    }
  }
}
