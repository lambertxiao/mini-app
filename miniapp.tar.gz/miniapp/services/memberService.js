import { Rest, regeneratorRuntime, Storage } from '../engine/index'

export default class MemberService {
  static isActivatedMember = async (channelId, unionId, openId) => {
    const params = { channelId, unionId, openId }
    const resp = await Rest.get('/crm/member/is-activated-member', params, true)

    if (resp.data.status === 'isNotActivated') {
      Storage.setItem(unionId + 'memberInfo', '')
      Storage.setItem(unionId + 'activeInfo', '')
    }

    return resp.data
  }

  static getMemberInfo = async (parksonMemberId) => {
    const params = { parksonMemberId }
    const resp = await Rest.get('/crm/member/get-member-info', params, true)

    return resp.data
  }

  static getDecryptPhone = async (channelId, jsCode, encryptedData, iv) => {
    const params = { channelId, jsCode, encryptedData, iv }
    const resp = await Rest.post('/crm/user-info/decrypt-data', params)

    return resp.data.phoneNumber
  }

  static getChannelName = async (channelId) => {
    const resp = await Rest.get('/common/channel/get-channel-info', { channelId })
    const { name } = resp.data[0]

    return name
  }
}
