# 注意

# 文件结构
> `engine`
>> `lib`            第三方的lib

> `components`      和业务逻辑无关公共组件

> `pages`          的页面

> `components`     components

> `extConfigs`      第三方小程序配置文件, 开发对应的小程序时，将该 *_ext.json 复制到 ext.json，开发完成以后(如果 ext.json 有改动)将 ext.json 复制到 *_ext.json 中。发布时选择相对应的 *_ext.json 转换成 String 发布

> `config`          网络请求默认 url 配置，以及 图片资源默认路径

# 第三方库

- regenerator.js 需要使用 async/await 的文件中，需要主动 import regenerator

# Engine

- index.js 将engine目录下的所有js文件export
- Enum.js 存放项目中用到的枚举变量
- I18N.js
- Rest.js 封装了Rest风格的http请求
- SequencePage.js 代替小程序默认的 page, 目的是为了等待 engine 初始化完成之后再加载 page
- Storage.js 封装了对微信Storage的操作
- TimeUtil.js
- Util.js
- wx.js 中封装了 wx 默认的 API 默认返回 promise

# Pages
## index.js

- 使用 engine/SequencePage 代替小程序默认的 page, 目的是为了等待 engine 初始化完成之后再加载 page

## index.scss
- 使用 flex 布局，style 尽可能的保持有序，先主要的布局，后padding，color, background 等。
- 单位统一使用 rpx, 根据 design 转换为 15px = 30rpx, 这里需要注意的是使用 wx 创建的动画中的单位是 px, Util 中提供了 rpx 转 px 的方法，动画中的用到的距离一定要将 view 的高度/宽度 和 margin 分开转成 px, 因为小程序在绘制视图的时候会有一个向下取整的操作
- 字体大小使用 rem, 跟为 16， 12px = 0.75rem

# 参考文档

- [微信获取 userinfo 流程](https://developers.weixin.qq.com/blogdetail?action=get_post_info&lang=zh_CN&token=&docid=000c2424654c40bd9c960e71e5b009)
- [群脉 oauth](http://developer.quncrm.com/wechat_oauth/)
