import regeneratorRuntime from './lib/regenerator'
import wx from './wx'

export default class ExtConfig {
  static getAppId = async () => {
    return await ExtConfig._getExtConfig('appId')
  }

  static getAccountId = async () => {
    return await ExtConfig._getExtConfig('accountId')
  }

  static _getExtConfig = async (key) => {
    const res = await wx.getExtConfig()
    if (res.errMsg === "getExtConfig: ok") {
      return res.extConfig[key]
    }

    return ''
  }
}
