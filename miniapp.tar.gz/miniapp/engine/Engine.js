import ExtConfig from './ExtConfig'
import { Scopes } from './Enum'
import Storage from './Storage'
import config from '../config.js'
import regeneratorRuntime from './lib/regenerator.js'
import wx from './wx.js'

export default class Engine {

  static Event = {
    OAUTH_FINISH: 'oauth-finish'
  }

  static oauthResult = null

  static accountId = null

  static engineInitPromise = null
  static engineInitPromiseResolve = null
  static engineInitPromiseReject = null

  static init = async (rest) => {
    if (Engine.engineInitPromise !== null) {
      return
    }

    Engine.engineInitPromise = new Promise((resolve, reject) => {
      Engine.engineInitPromiseResolve = resolve
      Engine.engineInitPromiseReject = reject
    })

    Engine.showLoading()

    try {
      Engine.rest = rest

      // 先从storage获取当前的login状态
      const accessToken = await Storage.getItem('accesstoken')
      const oauthResult = await Storage.getItem('oauthResult')
      Engine.oauthResult = oauthResult

      if (!accessToken || !oauthResult) {
        await Engine.login(Scopes.BASE)
      }

      // init rest
      const accountId = await Engine.getAccountId()
      const baseUrl = config.getBaseUrl()
      Engine.rest.baseUrl = `${baseUrl}/${accountId}/api`
    } catch (error) {
      Engine.engineInitPromiseReject(error)
      Engine.hideLoading()
      return
    }

    setTimeout(Engine.hideLoading, 200)
    Engine.engineInitPromiseResolve()
  }

  // 1. 调用wx.login获取code
  // 2. 根据code, appId, scope 等参数请求群脉oauth
  // 3. 无论scope为base还是userinfo, 返回结构一致
  //      openId：小程序用户的openId
  //      channlId: 小程序渠道的Id
  //      unionId: 微信用户唯一标识 详见UnionID机制说明
  //      member对象，结构见member (仅存在该用户时返回)
  // 4. 将返回的token写入storage中
  static login = async (oauthScope, showLoading = false) => {
    const accountId = await Engine.getAccountId()
    const { code } = await wx.login()
    const appid = await ExtConfig.getAppId()

    const data = await Engine._getOauthData(oauthScope, code, appid)

    // clear baseUrl
    Engine.rest.baseUrl = ''
    const baseOauthUrl = config.getOauthUrl()
    const oauthUrl = `${baseOauthUrl}/${accountId}/v2/weapp/oauth`
    const response = await Engine.rest.post(oauthUrl, data, showLoading)

    await Engine._setAccessToken(response)

    // reset baseUrl
    const baseUrl = config.getBaseUrl()
    Engine.rest.baseUrl = `${baseUrl}/${accountId}/api`
    Engine.oauthResult = response.data

    await Storage.setItem('oauthResult', Engine.oauthResult)
  }

  static _getOauthData = async (scope, code, appid) => {
    if (scope === Scopes.USER_INFO) {
      let encryptedData, iv
      let userInfo = {}

      try {
        ({ userInfo, encryptedData, iv } =  await wx.getUserInfo({ withCredentials: true }))
        Storage.setItem('userInfo', userInfo)
      } catch (error) {
        console.error('_getOauthData: ', error)
      }

      return { code, encrypted_data: encryptedData, iv, scope, watermark: { appid } }
    } else if (scope === Scopes.BASE) {
      return { code, scope: 'base', watermark: { appid } }
    }
  }

  // 在storage中写入token，以便下次访问
  static _setAccessToken = async (response) => {
    const reg = new RegExp("(^| |,)accesstoken" + "=([^;]*)(;)")
    const setCookie = response.header['Set-Cookie'] || response.header['set-cookie']
    const cookie = setCookie.match(reg)

    let accessToken
    if(cookie) {
      accessToken = cookie[2]
      await Storage.setItem('accesstoken', `accesstoken=${accessToken}`)
      Engine.rest.accesstoken = `accesstoken=${accessToken}`
    }
  }

  static setRestBaseData = (data) => {
    Engine.rest.data = { ...Engine.rest.data, ...data }
  }

  static getAccountId = async () => {
    return await ExtConfig.getAccountId()
  }

  static getMemberOpenId = () => {
    if (Engine.oauthResult) {
      return Engine.oauthResult.openId || Engine.oauthResult.origin_from.open_id
    }
  }

  static engineInitPromiseResolve = () => {
    Engine.engineInitPromise.resolve()
  }

  static engineInitPromiseReject = (error) => {
    Engine.engineInitPromise.reject(error)
  }

  static loadingCount = 0

  static showLoading = (title) => {
    Engine.loadingCount++
    if (title) {
      wx.showLoading({ title, mask: true })
      return
    }

    wx.showLoading({ title: '', mask: true })
  }

  static hideLoading = () => {
    Engine.loadingCount--
    if (Engine.loadingCount < 0) {
      Engine.loadingCount = 0
    }

    if (Engine.loadingCount > 0) {
      return
    }

    setTimeout(wx.hideLoading, 150)
  }

  static hasMember = async () => {
    const oauthResult = await Storage.getItem('oauthResult')
    if (oauthResult && (oauthResult.id || oauthResult.member)) {
      return true
    }

    return false
  }
}
