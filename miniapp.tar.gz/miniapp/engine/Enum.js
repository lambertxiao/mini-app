export const Scopes = {
  BASE: 'base',
  USER_INFO: 'userinfo',
  MEMBER: 'member'
}
